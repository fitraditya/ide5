ide5
====

ide5 - simple, pure HTML5 based code editor.

##Compatible Web Browser##
* Chrome (and also webkit based web browser)

##Features##
* Open file
* Download file
* Undo
* Redo
* Select all

##Screenshot##
![ide5](http://html5.web.id/ide5/ss.png)

##Demo##
[Demo](http://html5.web.id/ide5/)

##To Do##
* Others web browser compatibilty
* Find and replace function

##Maintainer##
* Fitra Aditya (fitra@g.pl)